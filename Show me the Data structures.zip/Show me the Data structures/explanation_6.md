This is to design the union and intersect function for a linkedlist
The linkedlist is first generated to empty. Then, it is populated with a list of elements.
A dictionary is used because its time complexity is linear and is used to populate a dictionary whose key is used populate the union linkedlist 
or intersect linkedlist respectively.