This is to design the union and intersect function for a linkedlist
The linkedlist is first generated to empty. Then, it is populated with a list of elements.
A dictionary is used because its time complexity is linear and is used to populate a dictionary whose key is used populate the union linkedlist 
or intersect linkedlist respectively.
The time complexity is Linear O(n) because of the Single for loop in the "union(llist_1, llist_2)" function. This means the algorithm increases or decreases with the number of inputs.