Hoffman code is used for file compression. It is a lossless data compression algorithm in that there is no loss of information.
It involves encoding and decoding. The encoding enables the data to be compressed into a smaller size and it can be decoded back to its original size.
A binary tree is the data structure that is used because to traverse each of the characters of the data as it encodes it down teh tree.
The time complexity is linear because of the For loop in the list comprehension used to generate the dictionary "frequency_dict". 
This denotes that for every input, there is direct and equal output.

