A blockchain is a sequential chain of records that contains blocks that contain information and cryptographic hash of the previous block
A linkedlist is the data structure used for block chain because it is similar to a linked list.
The time complexity is logarithm O(log n) due to the while loop in the "to_list(self)" function of the "BlockChain_LinkedList(object)" class. 
This signifies that the size of the input data reduces with each step.